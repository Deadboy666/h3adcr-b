#!/usr/bin/env bash
set -eu

    #paths
    SCRIPT_DIR="$(dirname "$(realpath "$0")")"
    SteamInstallDir=$HOME/.steam/steam
    SLSsteamInstallDir=$HOME/.local/share/SLSsteam
    SLSsteamConfigDir=$HOME/.config/SLSsteam
    InstallDir=$SCRIPT_DIR/bin
    RepoSLSsteamLocation=/usr/lib32

    checkforsteamcfg(){
        cd $SteamInstallDir/
    if [ -f "steam.cfg" ]; then
        rm steam.cfg
        notify-send "Once Steam Finishes Updating Exit Steam"
        steam
        conditioncheck
    else
        conditioncheck
    fi
        }
    downloadSLSsteam(){
        notify-send "Downloading Latest SLSsteam.."
        cd $SCRIPT_DIR/
        wget -O SLSsteam-Any.7z \
    $(curl -s https://api.github.com/repos/AceSLS/SLSsteam/releases/latest \
    | grep "browser_download_url" \
    | grep "SLSsteam-Any.7z" \
    | cut -d '"' -f 4)
    }

    extractSLSsteam(){
        downloadSLSsteam && sleep 1s
         7z x $SCRIPT_DIR/SLSsteam-Any.7z -aoa
         rm -rf tools
         rm -rf res
         rm setup.sh
         rm -rf docs
         rm SLSsteam-Any.7z
         notify-send "Latest SLSsteam Downloaded"
         }

    copySLSsteam(){
        extractSLSsteam
        cp $InstallDir/SLSsteam.so $SLSsteamInstallDir/
        }

    InstallSLSsteam(){
        notify-send "Installing SLSsteam..."
        if [ -d "$SLSsteamInstallDir" ]; then
          copySLSsteam
        else
            mkdir -p $SLSsteamInstallDir
            copySLSsteam
        fi
        }

    createsteamcfg(){
    cd $SteamInstallDir/
    if [ -f "steam.cfg" ]; then
        rm steam.cfg
    else
        cat << 'EOF' > steam.cfg
BootStrapperInhibitAll=enable
BootStrapperForceSelfUpdate=disable
EOF
    fi
        notify-send "steam.cfg Has Been Created..."
    }

    patchsteam(){
        if [ -f "$RepoSLSsteamLocation/libSLSsteam.so" ]; then
                notify-send "Patching Steam With Repo Library.."
                patchreposteam
        else
                InstallSLSsteam
                patchlocalsteam
        fi
        }

    patchreposteam(){
        cp $InstallDir/config.yaml $SLSsteamConfigDir/
        cd $SteamInstallDir/
        if grep -q -F "export LD_AUDIT=/usr/lib32/libSLSsteam.so" "steam.sh"; then
            noftify-send "Steam Runner Script Already Patched ,Skipping..."
        else
            notify-send "Patching Steam Runner Script..."
            sed -i '10a export LD_AUDIT=/usr/lib32/libSLSsteam.so' steam.sh
        fi
            notify-send "Steam Patched"
        }

    patchlocalsteam(){
        cp $InstallDir/config.yaml $SLSsteamConfigDir/
        cd $SteamInstallDir/
        if grep -q -F "export LD_AUDIT=$HOME/.local/share/SLSsteam/SLSsteam.so" "steam.sh"; then
            noftify-send "Steam Runner Script Already Patched ,Skipping..."
        else
            notify-send "Patching Steam Runner Script..."
            sed -i '10a export LD_AUDIT=$HOME/.local/share/SLSsteam/SLSsteam.so' steam.sh
        fi
            notify-send "Steam Patched"
        }

    steampuku(){
        notify-send "Nuking Steam"
        killall steam
        }

        conditioncheck(){
            notify-send "Checking Conditions..."
            createsteamcfg
            patchsteam
            }

    main(){
        checkforsteamcfg
        }

    main






